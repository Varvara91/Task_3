'use strict'
 
// Задание 1. Из массива в список

function arrayToList() {
	console.clear();
	var arr1 = [1, 2, 3];
	var lt = {rest: null};
	var lElem = {};
	for (var n=2; n>=0; n--) {
	
	lElem.value = arr1[n];
	lElem.rest = lt;	
	lt = lElem;
	console.log(lElem);
}
	return console.log(lElem);
}

function prepend(lt, x) {
	
	var lElem = {};
	lElem.value = x;
	lElem.rest = lt;
	lt = lElem;
	return console.log(lElem);
}

// Задание 1. Из списка в массив
function listToArray() {
	console.clear();
	var list2 = {value: 1, rest: {value: 2, rest: {value: 3, rest: null}}};
	var arr2 = [];
	for (var i = 0; i<3; i++){	
		arr2[i] = list2.value;
		list2 = list2.rest;
}
return console.log(arr2);
}

////////////////////////////////////////////////////
var lt2 = {value: 1, rest: {value: 2, rest: {value: 3, rest: null}}};
function nth(lt, index) {
	if (index>lt._length){
		return console.log('Такого элемента нет');
	} 
	
	for(var index in lt) {
		return console.log(lt[index]);
	}
}

nth(lt2, "1");

//Задача 2. Новый массив с обратным порядком элементов.
function reverseArray() {
	console.clear();
	var mass = [1,2,3,4,5,6,7,8,9];
	console.log(mass);
	var mass1 = [];
	var c = 0;
	for (var ind=(mass.length-1); ind>=0; ind--) {
		mass1[c] = mass[ind];
		c++;
	}
	return console.log(mass1);
}

//Задача 2. Обратный порядок в том массиве, который был передан в качестве аргумента.
function reverseArrayInPlace() {
	console.clear();
	var mass2 = [1,2,3,4];
	console.log(mass2);	
	var leng = mass2.length;
	var long = leng;
	var p = leng-1;
	for ( long; long<(leng*2); long++) {
		mass2[long] = mass2[p];
		p--;
	}
	mass2.splice(0,leng);
	return console.log(mass2);	
}

//Задача 3. Возвращает новый объект, куда вошли все ключи, указанные в массиве

function pick(obj, keys) {
	console.clear();
var user = {
    name: 'Sergey',
    age: 30,
    email: 'sergey@gmail.com',
    friends: ['Sveta', 'Artem']
	}
var keys = ['age', 'friends', 'city', 'name', 'type'];
var user2 ={};

	for (var r=0; r<keys.length; r++) {
		var j = keys[r];

		user2[j] = user[j];

	if(user2[j] == undefined) delete user2[j];
		}
	return console.log(user2);
}